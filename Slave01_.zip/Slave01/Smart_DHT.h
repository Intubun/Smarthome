#include <Arduino.h>

#include <DHT.h>

DHT dht(DHTPIN, DHTTYPE);

void dht_start(int P, ) { 
  float h = dht.readHumidity(); 
  float t = dht.readTemperature();
}
