#include "Smart_DHT.h"
#include <Arduino.h>
D HT_Sensor::DHT_Sensor(int p, int t) {
  
  }

DHT_Sensor::start(int P, int T) {
    PIN = P;
    TYPE = "DHT"T;
    DHT dht(DHTPIN, DHTTYPE);   
  
}

//DHT_Sensor::update() {
  
//  }
