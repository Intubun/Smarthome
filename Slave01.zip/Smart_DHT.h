#ifndef __DHT_SENSOR__
#define __DHT_SENSOR__

#include <Arduino.h>

#include <DHT.h>

class DHT_Sensor{
 private:
         byte TYPE;
         byte PIN;
 public:
        DHT_Sensor ();
};

#endif
//  float h = dht.readHumidity(); 
//  float t = dht.readTemperature();
