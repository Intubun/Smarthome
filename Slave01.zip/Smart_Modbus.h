#include <Arduino.h>

#include <ModbusRtu.h>
#define TXEN  2 
#define ID 1                                                                                                //definiere alle fürn Modbus relevante Variablen
#define BUS 1
uint16_t au16data[64] = {0};                                                                                //baue das Daten-Array für den Modbus
Modbus slave(ID,BUS,TXEN);
