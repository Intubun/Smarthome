#define DHT_PIN 3
#define DHT_TYPE DHT22

#define REGISTER 64
#define BUS 1
#define TXEN 2
#define ADR 1
