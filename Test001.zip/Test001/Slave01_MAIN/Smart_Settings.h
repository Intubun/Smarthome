#define DHT_PIN 3
#define DHT_TYPE DHT22
#define TEMP_R 9
#define HUDM_R 10

#define REGISTER 64
#define BUS 1
#define TXEN 2
#define ADR 1
#define BAUD 9600

#define Status_LED 13

#define R1 23
#define R2 25
#define R3 27
#define R4 29
#define R5 31
#define R6 33
#define R7 35
#define R8 37
