uint16_t au16data[REGISTER] = {0};
Modbus slave(ADR,BUS,TXEN);
